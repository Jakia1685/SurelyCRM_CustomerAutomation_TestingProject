# SurelyCRM Customer Management Automation

Selenium WebDriver + Pytest automation project for the public SurelyCRM demo.

## Application
https://demo.surelycrm.co.uk/

Public demo credentials:
- Username: `demo`
- Password: `Password1!`

## Automated end-to-end flow

```text
SurelyCRM
   ↓
Login
   ↓
Dashboard Verify
   ↓
Customer / Contact Management
   ↓
Create Customer
   ↓
Search Customer
   ↓
Verify Customer
   ↓
Logout
   ↓
PASSED
```

The test creates a demo customer, searches for it, verifies that it is displayed,
then logs out. Screenshots are saved for each major stage and an HTML report is generated.

## Run

Open PowerShell in this project folder:

```powershell
py -m pip install -r requirements.txt
py -m pytest --collect-only
py -m pytest -v -s
```

Expected collection:

```text
collected 1 item
```

Expected result after a successful run:

```text
1 passed
```

## Evidence

Screenshots:
- `screenshots/01_dashboard_verified.png`
- `screenshots/02_customers_page.png`
- `screenshots/03_customer_created.png`
- `screenshots/04_customer_search_verified.png`
- `screenshots/05_logout_verified.png`

HTML report:
- `reports/crm_report.html`

## Framework

- Python
- Selenium WebDriver
- Pytest
- Page Object Model (POM)
- Explicit waits
- HTML test report
- Screenshot evidence

## Note

The public demo resets periodically, so the visible data can change. The automation
uses semantic locators and creates a customer during the test rather than depending on
a pre-existing lead record.
