from pathlib import Path

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.common.exceptions import (
    TimeoutException,
    ElementClickInterceptedException,
)


class CustomersPage:
    """
    Page Object for SurelyCRM Customers module.

    Flow:
    Customers
        ↓
    Add Customer
        ↓
    Miss
        ↓
    First Name
        ↓
    Surname
        ↓
    Phone
        ↓
    Email
        ↓
    Save
        ↓
    Customer Created
    """

    def __init__(self, driver, timeout=30):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    # =========================================================
    # COMMON CLICK
    # =========================================================

    def _click_text(self, text):

        locator = (
            By.XPATH,
            f"//*[self::a or self::button]"
            f"[normalize-space()={text!r}]"
            f" | "
            f"//*[self::a or self::button]"
            f"[contains(normalize-space(.), {text!r})]"
        )

        element = self.wait.until(
            EC.element_to_be_clickable(locator)
        )

        self.driver.execute_script(
            """
            arguments[0].scrollIntoView({
                block: 'center',
                inline: 'center'
            });
            """,
            element
        )

        try:
            element.click()

        except ElementClickInterceptedException:
            self.driver.execute_script(
                "arguments[0].click();",
                element
            )

    # =========================================================
    # OPEN CUSTOMERS
    # =========================================================

    def open(self):

        print("\nOpening Customers...")

        self._click_text("Customers")

        self.loaded()

        print("✓ Customers page opened")

    # =========================================================
    # CUSTOMER PAGE LOADED
    # =========================================================

    def loaded(self):

        self.wait.until(
            EC.presence_of_element_located(
                (
                    By.XPATH,
                    "//*[contains("
                    "normalize-space(.),"
                    "'Customers'"
                    ")]"
                )
            )
        )

    # =========================================================
    # FIND FIRST VISIBLE ELEMENT
    # =========================================================

    def _first_visible(self, locators, timeout=10):

        last_error = None

        for locator in locators:

            try:

                return WebDriverWait(
                    self.driver,
                    timeout
                ).until(
                    EC.visibility_of_element_located(
                        locator
                    )
                )

            except Exception as exc:

                last_error = exc

        raise TimeoutException(
            "Customer form element was not found."
        ) from last_error

    # =========================================================
    # SELECT TITLE = MISS
    # =========================================================

    def _select_required_option(self):

        print("\nLooking for TITLE dropdown...")

        title_locators = [

            # Label -> select
            (
                By.XPATH,
                "//label[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'title')]"
                "/following::select[1]"
            ),

            # Any select
            (
                By.XPATH,
                "//select"
            ),
        ]

        for locator in title_locators:

            try:

                select_element = WebDriverWait(
                    self.driver,
                    10
                ).until(
                    EC.visibility_of_element_located(
                        locator
                    )
                )

                self.driver.execute_script(
                    """
                    arguments[0].scrollIntoView({
                        block: 'center'
                    });
                    """,
                    select_element
                )

                select = Select(select_element)

                print("✓ TITLE dropdown found")

                print("Available TITLE options:")

                for option in select.options:

                    print(
                        " - "
                        + option.text.strip()
                    )

                # -------------------------------------------------
                # SELECT MISS
                # -------------------------------------------------

                for option in select.options:

                    option_text = option.text.strip()

                    if option_text.lower() == "miss":

                        select.select_by_visible_text(
                            option_text
                        )

                        print(
                            "✓ TITLE selected: Miss"
                        )

                        return True

            except Exception as exc:

                print(
                    f"TITLE selection attempt failed: {exc}"
                )

        return False

    # =========================================================
    # ADD CUSTOMER
    # =========================================================

    def add_customer(
        self,
        first_name,
        last_name,
        email,
        phone
    ):

        print("\nOpening Add Customer...")

        # -----------------------------------------------------
        # Click Add Customer
        # -----------------------------------------------------

        self._click_text(
            "Add Customer"
        )

        # -----------------------------------------------------
        # Wait for New Customer page
        # -----------------------------------------------------

        self.wait.until(
            EC.presence_of_element_located(
                (
                    By.XPATH,
                    "//*[contains("
                    "normalize-space(.),"
                    "'New Customer'"
                    ")]"
                )
            )
        )

        print(
            "✓ New Customer page opened"
        )

        # =====================================================
        # TITLE = MISS
        # =====================================================

        if not self._select_required_option():

            raise AssertionError(
                "Could not select 'Miss' "
                "from TITLE dropdown."
            )

        # =====================================================
        # FIRST NAME
        # =====================================================

        print("\nEntering First Name...")

        first_field = self._first_visible(
            [

                (
                    By.CSS_SELECTOR,
                    "input[placeholder='Enter first name']"
                ),

                (
                    By.XPATH,
                    "//input[contains("
                    "translate(@placeholder,"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'first name')]"
                ),

                (
                    By.NAME,
                    "firstName"
                ),

                (
                    By.ID,
                    "firstName"
                ),

                (
                    By.NAME,
                    "firstname"
                ),

                (
                    By.ID,
                    "firstname"
                ),

                (
                    By.XPATH,
                    "//label[contains("
                    "translate(normalize-space(.),"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'firstname')]"
                    "/following::input[1]"
                ),
            ],
            timeout=10
        )

        first_field.clear()

        first_field.send_keys(
            first_name
        )

        print(
            f"✓ First Name: {first_name}"
        )

        # =====================================================
        # LAST NAME / SURNAME
        # =====================================================

        print("\nEntering Surname...")

        last_field = self._first_visible(
            [

                (
                    By.CSS_SELECTOR,
                    "input[placeholder='Enter surname']"
                ),

                (
                    By.XPATH,
                    "//input[contains("
                    "translate(@placeholder,"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'surname')]"
                ),

                (
                    By.NAME,
                    "lastName"
                ),

                (
                    By.ID,
                    "lastName"
                ),

                (
                    By.NAME,
                    "lastname"
                ),

                (
                    By.ID,
                    "lastname"
                ),

                (
                    By.XPATH,
                    "//label[contains("
                    "translate(normalize-space(.),"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'surname')]"
                    "/following::input[1]"
                ),

                (
                    By.XPATH,
                    "//label[contains("
                    "translate(normalize-space(.),"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'last')]"
                    "/following::input[1]"
                ),
            ],
            timeout=10
        )

        last_field.clear()

        last_field.send_keys(
            last_name
        )

        print(
            f"✓ Surname: {last_name}"
        )

        # =====================================================
        # MOBILE PHONE
        # =====================================================

        print("\nEntering Mobile Phone...")

        phone_field = self._first_visible(
            [

                (
                    By.CSS_SELECTOR,
                    "input[placeholder='Enter mobile phone']"
                ),

                (
                    By.XPATH,
                    "//input[contains("
                    "translate(@placeholder,"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'mobile phone')]"
                ),

                (
                    By.NAME,
                    "mobile"
                ),

                (
                    By.ID,
                    "mobile"
                ),

                (
                    By.NAME,
                    "phone"
                ),

                (
                    By.ID,
                    "phone"
                ),

                (
                    By.XPATH,
                    "//label[contains("
                    "translate(normalize-space(.),"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'mobile')]"
                    "/following::input[1]"
                ),
            ],
            timeout=10
        )

        phone_field.clear()

        phone_field.send_keys(
            phone
        )

        print(
            f"✓ Mobile Phone: {phone}"
        )

        # =====================================================
        # EMAIL
        # =====================================================

        print("\nEntering Email...")

        email_field = self._first_visible(
            [

                (
                    By.CSS_SELECTOR,
                    "input[placeholder='Enter email address']"
                ),

                (
                    By.XPATH,
                    "//input[contains("
                    "translate(@placeholder,"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'email address')]"
                ),

                (
                    By.NAME,
                    "email"
                ),

                (
                    By.ID,
                    "email"
                ),

                (
                    By.CSS_SELECTOR,
                    "input[type='email']"
                ),

                (
                    By.XPATH,
                    "//label[contains("
                    "translate(normalize-space(.),"
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                    "'abcdefghijklmnopqrstuvwxyz'),"
                    "'email')]"
                    "/following::input[1]"
                ),
            ],
            timeout=10
        )

        email_field.clear()

        email_field.send_keys(
            email
        )

        print(
            f"✓ Email: {email}"
        )

        # =====================================================
        # SCREENSHOT - ADD CUSTOMER FORM
        # =====================================================

        Path("screenshots").mkdir(
            parents=True,
            exist_ok=True
        )

        self.driver.save_screenshot(
            "screenshots/02_add_customer_form.png"
        )

        print(
            "✓ Screenshot saved: "
            "02_add_customer_form.png"
        )

        # =====================================================
        # SAVE CUSTOMER
        # =====================================================

        print("\nLooking for Save button...")

        save_locators = [

            (
                By.XPATH,
                "//button[normalize-space()='Save']"
            ),

            (
                By.XPATH,
                "//button[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'save')]"
            ),

            (
                By.XPATH,
                "//input[@type='submit']"
            ),

            (
                By.CSS_SELECTOR,
                "button[type='submit']"
            ),
        ]

        save_button = self._first_visible(
            save_locators,
            timeout=15
        )

        self.driver.execute_script(
            """
            arguments[0].scrollIntoView({
                block: 'center'
            });
            """,
            save_button
        )

        self.wait.until(
            lambda driver:
            save_button.is_enabled()
        )

        try:

            save_button.click()

        except ElementClickInterceptedException:

            self.driver.execute_script(
                "arguments[0].click();",
                save_button
            )

        print(
            "✓ Save button clicked"
        )

        # =====================================================
        # WAIT FOR CUSTOMER CREATED
        # =====================================================

        try:

            WebDriverWait(
                self.driver,
                15
            ).until(
                EC.any_of(

                    EC.url_contains(
                        "customer"
                    ),

                    EC.url_contains(
                        "customers"
                    ),

                    EC.presence_of_element_located(
                        (
                            By.XPATH,
                            "//*[contains("
                            "normalize-space(.),"
                            "'Customer'"
                            ")]"
                        )
                    )
                )
            )

        except Exception:

            pass

        print(
            "✓ Customer creation completed"
        )

        # =====================================================
        # SCREENSHOT - CUSTOMER CREATED
        # =====================================================

        self.driver.save_screenshot(
            "screenshots/03_customer_created.png"
        )

        print(
            "✓ Screenshot saved: "
            "03_customer_created.png"
        )

    # =========================================================
    # LOGOUT
    # =========================================================

    def logout(self):

        print(
            "\nLogging out..."
        )

        # -----------------------------------------------------
        # OPEN DEMO MENU
        # -----------------------------------------------------

        menu_locators = [

            (
                By.XPATH,
                "//button[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'demo')]"
            ),

            (
                By.XPATH,
                "//*[self::button or self::div]"
                "[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'demo')]"
            ),
        ]

        menu = self._first_visible(
            menu_locators,
            timeout=10
        )

        self.driver.execute_script(
            """
            arguments[0].scrollIntoView({
                block: 'center'
            });
            """,
            menu
        )

        try:

            menu.click()

        except ElementClickInterceptedException:

            self.driver.execute_script(
                "arguments[0].click();",
                menu
            )

        # -----------------------------------------------------
        # LOGOUT BUTTON
        # -----------------------------------------------------

        logout_locators = [

            (
                By.XPATH,
                "//*[self::button or self::a]"
                "[normalize-space()='Logout']"
            ),

            (
                By.XPATH,
                "//*[self::button or self::a]"
                "[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'logout')]"
            ),

            (
                By.XPATH,
                "//*[self::button or self::a]"
                "[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'log out')]"
            ),
        ]

        logout_button = self._first_visible(
            logout_locators,
            timeout=10
        )

        self.driver.execute_script(
            """
            arguments[0].scrollIntoView({
                block: 'center'
            });
            """,
            logout_button
        )

        try:

            logout_button.click()

        except ElementClickInterceptedException:

            self.driver.execute_script(
                "arguments[0].click();",
                logout_button
            )

        print(
            "✓ Logout clicked"
        )