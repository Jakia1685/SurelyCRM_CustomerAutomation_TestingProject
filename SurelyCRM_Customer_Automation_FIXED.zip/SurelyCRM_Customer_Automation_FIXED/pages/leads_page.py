from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class LeadsPage:
    def __init__(self, driver, timeout=25):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open(self):
        locator = (
            By.XPATH,
            "//a[normalize-space()='Leads'] | "
            "//button[normalize-space()='Leads'] | "
            "//*[self::a or self::button][contains(normalize-space(.),'Leads')]"
        )
        self.wait.until(EC.element_to_be_clickable(locator)).click()

    def loaded(self):
        self.wait.until(EC.presence_of_element_located(
            (By.XPATH,
             "//*[self::h1 or self::h2 or self::div or self::span]"
             "[normalize-space()='Leads']")
        ))

    def search(self, text):
        field = self.wait.until(EC.visibility_of_element_located((
            By.XPATH,
            "//input[contains(translate(@placeholder,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search') "
            "or contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search') "
            "or contains(translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]"
        )))
        field.clear()
        field.send_keys(text)

        # Some versions filter immediately; if a filter/search button exists,
        # click it. Otherwise leave the entered search text in place.
        buttons = [
            (By.XPATH,
             "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'filter')]"),
            (By.XPATH,
             "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]"),
        ]
        for locator in buttons:
            try:
                self.wait.until(EC.element_to_be_clickable(locator)).click()
                break
            except Exception:
                pass

    def has_lead(self, business_name):
        locator = (
            By.XPATH,
            f"//*[contains(normalize-space(.), {business_name!r})]"
        )
        try:
            self.wait.until(EC.presence_of_element_located(locator))
            return True
        except Exception:
            return False
