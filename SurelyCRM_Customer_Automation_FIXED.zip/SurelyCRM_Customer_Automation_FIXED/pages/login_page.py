from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class LoginPage:

    URL = "https://demo.surelycrm.co.uk/login"

    def __init__(self, driver, timeout=30):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    # =====================================================
    # OPEN LOGIN PAGE
    # =====================================================

    def open(self):
        self.driver.get(self.URL)

    # =====================================================
    # FIND FIRST VISIBLE ELEMENT
    # =====================================================

    def _first_visible(self, locators, timeout=15):

        last_error = None

        for locator in locators:

            try:
                return WebDriverWait(
                    self.driver,
                    timeout
                ).until(
                    EC.visibility_of_element_located(locator)
                )

            except Exception as exc:
                last_error = exc

        raise AssertionError(
            "Login input was not found."
        ) from last_error

    # =====================================================
    # LOGIN
    # =====================================================

    def login(self, username, password):

        print("\nEntering username...")

        user = self._first_visible([
            (
                By.CSS_SELECTOR,
                "input[placeholder='Enter your username']"
            ),
            (
                By.NAME,
                "username"
            ),
            (
                By.ID,
                "username"
            ),
            (
                By.NAME,
                "email"
            ),
            (
                By.ID,
                "email"
            ),
            (
                By.CSS_SELECTOR,
                "input[type='text']"
            ),
            (
                By.CSS_SELECTOR,
                "input[type='email']"
            ),
            (
                By.XPATH,
                "//input[contains("
                "translate(@placeholder,"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'username')]"
            ),
        ])

        user.clear()
        user.send_keys(username)

        print("Username entered.")

        print("Entering password...")

        password_field = self._first_visible([
            (
                By.CSS_SELECTOR,
                "input[placeholder='Enter your password']"
            ),
            (
                By.NAME,
                "password"
            ),
            (
                By.ID,
                "password"
            ),
            (
                By.CSS_SELECTOR,
                "input[type='password']"
            ),
            (
                By.XPATH,
                "//input[contains("
                "translate(@placeholder,"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'password')]"
            ),
        ])

        password_field.clear()
        password_field.send_keys(password)

        print("Password entered.")

        # =================================================
        # SIGN IN
        # =================================================

        print("Clicking Sign in...")

        button = self._first_visible([
            (
                By.XPATH,
                "//button[normalize-space()='Sign in']"
            ),
            (
                By.XPATH,
                "//button[contains("
                "translate(normalize-space(.),"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                "'abcdefghijklmnopqrstuvwxyz'),"
                "'sign in')]"
            ),
            (
                By.XPATH,
                "//input[@type='submit']"
            ),
            (
                By.CSS_SELECTOR,
                "button[type='submit']"
            ),
        ])

        self.wait.until(
            EC.element_to_be_clickable(button)
        ).click()

        print("Sign in clicked.")

    # =====================================================
    # DASHBOARD LOADED
    # =====================================================

    def dashboard_loaded(self):

        self.wait.until(
            EC.any_of(

                EC.url_contains("/Dashboard"),

                EC.url_contains("/dashboard"),

                EC.url_contains("/home"),

                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        "//*[contains("
                        "normalize-space(.),"
                        "'Hello, demo')]"
                    )
                ),

                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        "//*[contains("
                        "normalize-space(.),"
                        "'Demo Holidays CRM')]"
                    )
                ),

                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        "//*[normalize-space()='Dashboard']"
                    )
                ),
            )
        )

        print("Dashboard loaded successfully.")