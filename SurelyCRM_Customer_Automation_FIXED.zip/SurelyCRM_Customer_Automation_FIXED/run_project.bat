@echo off
py -m pytest -v -s
pause
