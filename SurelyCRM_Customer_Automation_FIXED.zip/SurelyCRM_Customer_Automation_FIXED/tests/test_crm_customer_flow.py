from pathlib import Path

from pages.login_page import LoginPage
from pages.customers_page import CustomersPage


USERNAME = "demo"
PASSWORD = "Password1!"

CUSTOMER_FIRST = "Jakia"
CUSTOMER_LAST = "Sultana"
CUSTOMER_EMAIL = "jakia1685@gmail.com"
CUSTOMER_PHONE = "01300000000"


def _shot(driver, name):

    Path("screenshots").mkdir(
        exist_ok=True
    )

    driver.save_screenshot(
        f"screenshots/{name}.png"
    )


def test_crm_login_customer_create_logout(driver):

    print("\n======================================")
    print("SURELY CRM AUTOMATION TEST STARTED")
    print("======================================")

    login = LoginPage(driver)
    customers = CustomersPage(driver)

    # =====================================================
    # 1. LOGIN
    # =====================================================

    print("\n[1] LOGIN")

    login.open()

    login.login(
        USERNAME,
        PASSWORD
    )

    login.dashboard_loaded()

    print("LOGIN PASSED")

    _shot(
        driver,
        "01_login"
    )

    # =====================================================
    # 2. CUSTOMERS
    # =====================================================

    print("\n[2] CUSTOMERS")

    customers.open()

    customers.loaded()

    print("CUSTOMERS PAGE PASSED")

    # =====================================================
    # 3. ADD CUSTOMER
    # =====================================================

    print("\n[3] ADD CUSTOMER")

    customers.add_customer(
        CUSTOMER_FIRST,
        CUSTOMER_LAST,
        CUSTOMER_EMAIL,
        CUSTOMER_PHONE
    )

    print("CUSTOMER CREATED")

    _shot(
        driver,
        "03_customer_created"
    )

    # =====================================================
    # 4. LOGOUT
    # =====================================================

    print("\n[4] LOGOUT")

    customers.logout()

    login.wait.until(
        lambda d:
        "/login" in d.current_url.lower()
    )

    print("LOGOUT PASSED")

    _shot(
        driver,
        "04_logout_verified"
    )

    # =====================================================
    # FINAL
    # =====================================================

    print("\n======================================")
    print("CUSTOMER CREATION FLOW PASSED")
    print("======================================")